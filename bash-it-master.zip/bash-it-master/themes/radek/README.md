# Radek Theme

A colorful theme for Python developers.
It does not have any requirments.

## Provided Information

* Current username and hostname
* Current path
* Git repository status
* Current Python environment (venv, Conda )
* Current Python version

## Examples

```bash
[radek@photon][~/src/nokia2/cbis] ±[master → origin ↑1 {1}✓][venv-cbis][py-3.7.5]
→
```
