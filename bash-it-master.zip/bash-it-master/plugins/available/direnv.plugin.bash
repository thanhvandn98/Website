cite about-plugin
about-plugin 'load direnv, if you are using it: https://direnv.net/'

[ -x "$(which direnv)" ] && eval "$(direnv hook bash)"
