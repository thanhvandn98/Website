cite about-plugin
about-plugin 'Enable emacs editing mode'

set -o emacs
