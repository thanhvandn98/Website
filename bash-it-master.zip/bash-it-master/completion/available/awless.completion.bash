[[ -x "$(which awless)" ]] && source <(awless completion bash)
