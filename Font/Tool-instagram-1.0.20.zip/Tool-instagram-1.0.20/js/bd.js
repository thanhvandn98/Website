$(document).ready(function() {
    var api = "https://i.instagram.com/api/v1/";
    console.log('Bip bip');

    // chrome.storage.local.set({
    //     'taskArray': []
    // }, function() {});

    function restartDataApp() {
        chrome.storage.local.set({
            'jobs': []
        }, function() {});
        chrome.storage.local.set({
            'profileArray': []
        }, function() {});
        var data = {
            id: 0,
            timeNext: 0
        };
        chrome.storage.local.set({
            'currentTasks': data
        }, function() {});
        chrome.storage.local.set({
            'dataProfileArray': []
        }, function() {});
    }
    restartDataApp();

    var setting = {
        sign: 0
    };
    var ds_user_id = '';
    var csrftoken = '';
    chrome.storage.local.set({
        'ds_user_id': ''
    }, function() {})
    
    

    //Ajax to server get data
    function checkSetting() {

        chrome.storage.local.set({
            'csrftoken': ''
        }, function() {})

        $.ajax({
            url: 'https://www.instagram.com',
            type: 'GET',
            success: function(data) {
                var data = data.split('window._sharedData = ')[1];
                data = data.split(';</script>')[0];
                data = JSON.parse(data);

                if (data.config != null) {

                    csrftoken = data.config.csrf_token;
                    chrome.storage.local.set({
                        'csrftoken': csrftoken
                    }, function() {})

                    console.log(data.config);

                    try {
                        ds_user_id = data.config.viewer.id
                    } catch(err) {
                        ds_user_id = data.config.viewerId
                    }

                    
                    chrome.storage.local.set({
                        'ds_user_id': ds_user_id
                    }, function() {})
                    
                }


                console.log(csrftoken);
                if (csrftoken != '' && setting.sign == 0) {
                    $.get('https://api.puno2.com/api/instagram', function(data) {
                        console.log(data);
                        var currentdate = new Date();
                        var t = currentdate.getTime();
                        if ((t - data.sign) < 360000000) {
                            setting = data;
                        } else {
                            setting = {
                                sign: 0
                            };
                        }
                    });
                }
            }
        });
    }
    checkSetting();

    // if setting != []
    // Run


    setInterval(function() {
        var currentdate = new Date();
        var day = currentdate.getDay();
        if ((day % 7) == 0) {
            chrome.storage.local.get('profileArray', function(resultprofileArray) {

                if (typeof resultprofileArray.profileArray != 'undefined') {

                    chrome.storage.local.get('dataProfileArray', function(resultDataProfileArray) {
                        if (typeof resultDataProfileArray.dataProfileArray != 'undefined') {
                            var unix = Math.round(+new Date() / 1000);
                            for (var i = 0; i < resultDataProfileArray.dataProfileArray.length; i++) {
                                if ((unix - resultDataProfileArray.dataProfileArray[i].time) > 604800) {
                                    // Delete
                                    resultprofileArray.profileArray.slice(i, 1);
                                    resultDataProfileArray.dataProfileArray.slice(i, 1);
                                } else {
                                    break;
                                }
                            }

                            chrome.storage.local.set({
                                'profileArray': resultprofileArray.profileArray
                            }, function() {});
                            chrome.storage.local.set({
                                'dataProfileArray': resultDataProfileArray.dataProfileArray
                            }, function() {});
                        }
                    });

                }

            });
        }
    }, 360000);

    chrome.storage.local.get('currentTasks', function(result) {
        if (typeof result.currentTasks != "undefined") {

            var unix = Math.round(+new Date() / 1000);
            if (unix > result.currentTasks.timeNext) {
                console.log('Run 11');
                runTask();
            } else {
                console.log('Run 22');
            }
        } else {
            console.log('Run 33');
            runTask();
        }
    });

    function increatCountToDay() {
        chrome.storage.local.get('today', function(result) {
            if (typeof result.today != 'undefined') {
                var dataToday = result.today;
                dataToday.count += 1;
                chrome.storage.local.set({
                    'today': dataToday
                }, function() {});
            } else {
                var dataToday = {
                    count: 1
                };
                chrome.storage.local.set({
                    'today': dataToday
                }, function() {});
            }

        });
    }

    setInterval(function() {
        chrome.storage.local.get('today', function(result) {
            if (typeof result.today != "undefined") {
                var currentdate = new Date();
                var today = currentdate.getDay() + "/" + currentdate.getMonth() + "/" + currentdate.getFullYear();
                if (result.today.datetime != today) {
                    //restart count today
                    var dataToday = {
                        datetime: today,
                        count: 0
                    };
                    chrome.storage.local.set({
                        'today': dataToday
                    }, function() {});
                }
            }

        });
        chrome.storage.local.get('currentTasks', function(result) {
            if (typeof result.currentTasks != "undefined") {
                var unix = Math.round(+new Date() / 1000);

                console.log(result.currentTasks);

                if (unix > result.currentTasks.timeNext) {
                    runTask();
                    console.log('1');
                } else {
                    console.log('2');
                }
            } else {
                runTask();
                console.log('3');
            }
        });
    }, 60000);

    function runTask() {
        console.log('runTask');
        chrome.storage.local.get('csrftoken', function(r) {

            if (r.csrftoken != '') {
                chrome.storage.local.get('tasks', function(_result) {
                    if (typeof _result.tasks != "undefined") {

                        chrome.storage.local.get('currentTasks', function(__result) {

                            if (_result.tasks.length == 0) {
                                console.log(_result.tasks);
                                return;
                            }

                            var t = 0;

                            if (typeof __result.currentTasks != "undefined") {
                                for (var i = 0; i < _result.tasks.length; i++) {
                                    if (_result.tasks[i].id == __result.currentTasks.id) {
                                        t = i + 1;
                                        break;
                                    }
                                }
                            } else {
                                t = 0;
                            }

                            if (t >= _result.tasks.length) {

                                console.log('t max ' + t);
                                t = 0;
                                var newJobs = [];
                                var r = Math.floor((Math.random() * 16) + 8);
                                for (var i = r; i > 0; i--) {
                                    var message = "Sleep in " + i + " min";
                                    var job = {
                                        type: 'sleep',
                                        time: 60000,
                                        message: message
                                    };
                                    newJobs.push(job);
                                }

                                chrome.storage.local.get('jobs', function(_result) {
                                    var jobs = [];
                                    if (typeof _result.jobs != "undefined") {
                                        jobs = _result.jobs;
                                    }
                                    jobs = newJobs.concat(jobs);
                                    chrome.storage.local.set({
                                        'jobs': jobs
                                    }, function(__result) {});
                                });
                            }

                            console.log(_result.tasks);
                            console.log(_result.tasks[t]);
                            console.log(t);

                            console.log(_result.tasks[t].type);

                            switch (_result.tasks[t].type) {
                                case 'like-tag-task':
                                    console.log(_result.tasks[t].dataTask);

                                    var hashtags = _result.tasks[t].dataTask.split(' ');
                                    console.log(hashtags.length);

                                    for (var j = 0; j < hashtags.length; j++) {
                                        var text = hashtags[j].replace('#', '');
                                        searchHTML('https://www.instagram.com/explore/tags/' + text + '/', text, _result.tasks[t].type);
                                    }
                                    break;
                                case 'like-location-task':
                                    var texts = _result.tasks[t].dataTask.split(' ');
                                    for (var j = 0; j < texts.length; j++) {
                                        var text = texts[j].replace('https://www.instagram.com/explore/locations/', '');
                                        text = text.split('/')[0]
                                        searchHTML(texts[j], text, _result.tasks[t].type);
                                    }
                                    break;
                                case 'like-user-task':
                                    var users = _result.tasks[t].dataTask.split(' ');
                                    for (var j = 0; j < users.length; j++) {
                                        var text = users[j].replace('@', '');
                                        searchHTML('https://www.instagram.com/' + text + '/', text, _result.tasks[t].type);
                                    }
                                    break;
                                case 'follow-tag-task':
                                    var hashtags = _result.tasks[t].dataTask.split(' ');
                                    for (var j = 0; j < hashtags.length; j++) {
                                        var text = hashtags[j].replace('#', '');
                                        searchHTML('https://www.instagram.com/explore/tags/' + text + '/', text, _result.tasks[t].type);
                                    }
                                    break;
                                case 'follow-location-task':
                                    var texts = _result.tasks[t].dataTask.split(' ');
                                    for (var j = 0; j < texts.length; j++) {
                                        var text = texts[j].replace('https://www.instagram.com/explore/locations/', '');
                                        text = text.split('/')[0]
                                        searchHTML(texts[j], text, _result.tasks[t].type);
                                    }
                                    break;
                                case 'follow-user-task':
                                    var users = _result.tasks[t].dataTask.split(' ');
                                    for (var j = 0; j < users.length; j++) {
                                        var text = users[j].replace('@', '');
                                        searchHTML('https://www.instagram.com/' + text + '/', text, _result.tasks[t].type);
                                    }
                                    break;
                                default:
                                    console.log('Wat')

                            }


                            var unix = Math.round(+new Date() / 1000);
                            var r = Math.floor((Math.random() * 27) + 19);
                            var timeNext = unix + (r * 60);
                            var _data = {
                                id: _result.tasks[t].id,
                                timeNext: timeNext
                            };
                            chrome.storage.local.set({
                                'currentTasks': _data
                            }, function() {});

                            var message = 'Run task ' + _result.tasks[t].dataTask;
                            chrome.storage.local.set({
                                'appStatus': message
                            }, function() {});

                        });

                    } else {
                      console.log('Not found tasks');
                    }
                });
            } else {
                checkSetting();
                setTimeout(function() {
                    runTask();
                }, 400000);
                console.log('Not found crstok');
            }
        });


    }

    function searchHTML(url, text, typeTask) {

        console.log(url);
        $.ajax({
            url: url,
            type: 'GET',
            success: function(data) {
                var data = data.split('window._sharedData = ')[1];
                data = data.split(';</script>')[0];
                data = JSON.parse(data);

                var imgs = [];
                var newJobs = [];

                chrome.storage.local.get('jobs', function(_result) {
                    var jobs = [];
                    if (typeof _result.jobs != "undefined") {
                        jobs = _result.jobs;
                    }

                    switch (typeTask) {
                        case 'like-tag-task':
                            console.log(data)
                            // imgs = data.entry_data.TagPage[0].tag.media.nodes;
                            imgs = data.entry_data.TagPage[0].graphql.hashtag.edge_hashtag_to_media.edges;
                            // console.log(imgs);
                            for (var i = 0; i < imgs.length; i++) {
                                var time = Math.floor(Math.random() * 70000) + 40001
                                var job = {
                                    type: 'like',
                                    text: text,
                                    shortcode: imgs[i].node.shortcode,
                                    id: imgs[i].node.id,
                                    display_url: imgs[i].node.thumbnail_src,
                                    time: time
                                };
                                jobs.push(job);
                            }

                            if (data.entry_data.TagPage[0].graphql.hashtag.edge_hashtag_to_media.page_info.has_next_page) {
                                if (typeof text != "undefined") {
                                    var message = 'Search #' + text;
                                    var job = {
                                        type: 'search',
                                        text: text,
                                        message: message,
                                        after: data.entry_data.TagPage[0].graphql.hashtag.edge_hashtag_to_media.page_info.end_cursor,
                                        time: 70000,
                                        typeTask: typeTask
                                    };
                                    jobs.push(job);
                                }

                            }

                            break;
                        case 'like-location-task':
                            console.log(data)
                            imgs = data.entry_data.LocationsPage[0].graphql.location.edge_location_to_media.edges;
                            console.log(imgs.length)
                            for (var i = 0; i < imgs.length; i++) {
                                var time = Math.floor(Math.random() * 70000) + 40001
                                var job = {
                                    type: 'like',
                                    text: text,
                                    shortcode: imgs[i].node.shortcode,
                                    id: imgs[i].node.id,
                                    display_url: imgs[i].node.thumbnail_src,
                                    time: time
                                };
                                jobs.push(job);
                            }

                            if (data.entry_data.LocationsPage[0].graphql.location.edge_location_to_media.page_info.has_next_page) {
                                var message = 'Search ' + text;
                                var job = {
                                    type: 'search',
                                    text: text,
                                    message: message,
                                    after: data.entry_data.LocationsPage[0].graphql.location.edge_location_to_media.page_info.end_cursor,
                                    time: 70000,
                                    typeTask: typeTask
                                };
                                jobs.push(job);
                            }
                            break;
                        case 'like-user-task':
                            console.log(data)

                            var text = data.entry_data.ProfilePage[0].graphql.user.id;
                            var message = 'Search follower @' + data.entry_data.ProfilePage[0].graphql.user.username;
                            var job = {
                                type: 'search',
                                text: text,
                                message: message,
                                after: '',
                                time: 70000,
                                typeTask: typeTask
                            };
                            jobs.push(job);
                            break;
                        case 'search-profile':

                            console.log(data)
                            imgs = data.entry_data.ProfilePage[0].graphql.user.edge_owner_to_timeline_media.edges;
                            console.log('search-profile count');
                            for (var i = 0; i < imgs.length && i < 5; i++) {
                                var time = Math.floor(Math.random() * 70000) + 40001
                                var job = {
                                    type: 'like',
                                    text: text,
                                    shortcode: imgs[i].node.shortcode,
                                    id: imgs[i].node.id,
                                    display_url: imgs[i].node.thumbnail_src,
                                    time: time
                                };
                                jobs.unshift(job);
                            }
                            break;
                            
                        case 'follow-tag-task':
                            console.log(data)

                            imgs = data.entry_data.TagPage[0].graphql.hashtag.edge_hashtag_to_media.edges;
                            // console.log(imgs);
                            for (var i = 0; i < imgs.length; i++) {
                                var time = Math.floor(Math.random() * 70000) + 40001;
                                var job = {
                                    type: 'follow',
                                    text: text,
                                    shortcode: imgs[i].node.shortcode,
                                    id: imgs[i].node.owner.id,
                                    display_url: imgs[i].node.thumbnail_src,
                                    time: time
                                };
                                jobs.push(job);
                            }

                            if (data.entry_data.TagPage[0].graphql.hashtag.edge_hashtag_to_media.page_info.has_next_page) {
                                if (typeof text != "undefined") {
                                    var message = 'Search #' + text;
                                    var job = {
                                        type: 'search',
                                        text: text,
                                        message: message,
                                        after: data.entry_data.TagPage[0].graphql.hashtag.edge_hashtag_to_media.page_info.end_cursor,
                                        time: 70000,
                                        typeTask: typeTask
                                    };
                                    jobs.push(job);
                                }
                            }

                            break;
                        case 'follow-location-task':
                            console.log(data)

                            imgs = data.entry_data.LocationsPage[0].graphql.location.edge_location_to_media.edges;
                            for (var i = 0; i < imgs.length; i++) {
                                var time = Math.floor(Math.random() * 70000) + 40001
                                var job = {
                                    type: 'follow',
                                    text: text,
                                    shortcode: imgs[i].node.shortcode,
                                    id: imgs[i].node.owner.id,
                                    display_url: imgs[i].node.thumbnail_src,
                                    time: time
                                };
                                jobs.push(job);
                            }
                            if (data.entry_data.LocationsPage[0].graphql.location.edge_location_to_media.page_info.has_next_page) {
                                var message = 'Search ' + text;
                                var job = {
                                    type: 'search',
                                    text: text,
                                    message: message,
                                    after: data.entry_data.LocationsPage[0].graphql.location.edge_location_to_media.page_info.end_cursor,
                                    time: 70000,
                                    typeTask: typeTask
                                };
                                jobs.push(job);
                            }
                            break;
                        case 'follow-user-task':
                            console.log(data)

                            var users = data.user.edge_followed_by.edges;
                            for (var i = 0; i < peoples.length; i++) {
                                var time = Math.floor(Math.random() * 70000) + 40001
                                var job = {
                                    type: 'follow',
                                    text: text,
                                    shortcode: '',
                                    id: users[i].node.id,
                                    display_url: users[i].node.profile_pic_url,
                                    time: time
                                };
                                jobs.push(job);
                            }
                            if (data.user.edge_followed_by.page_info.has_next_page) {
                                var message = 'Search ' + text;
                                var job = {
                                    type: 'search',
                                    text: text,
                                    message: message,
                                    after: data.entry_data.LocationsPage[0].graphql.location.edge_location_to_media.page_info.end_cursor,
                                    time: 70000,
                                    typeTask: typeTask
                                };
                                jobs.push(job);
                            }
                            break;
                        default:
                            console.log('Wtf');
                    }

                    chrome.storage.local.set({
                        'jobs': jobs
                    }, function() {});
                });

            }
        });
    }

    function search(text, after, typeTask) {
        if (after == null) {
            after = '';
        }

        var url = '';
        switch (typeTask) {
            case 'like-tag-task':
                if (after === '') {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[0]) + '&variables=%7B%22tag_name%22:%22' + text + '%22,%22first%22:12%7D';
                } else {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[0]) + '&variables=%7B%22tag_name%22:%22' + text + '%22,%22first%22:12,%22after%22:%22' + after + '%22%7D';
                }
                break;
            case 'like-location-task':
                if (after === '') {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[1]) + '&variables=%7B%22id%22:%22' + text + '%22,%22first%22:12%7D';
                } else {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[1]) + '&variables=%7B%22id%22:%22' + text + '%22,%22first%22:12,%22after%22:%22' + after + '%22%7D';
                }
                break;
            case 'like-user-task':
                if (after === '') {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[2]) + '&variables=%7B%22id%22%3A%22' + text + '%22%2C%22first%22%3A20%7D';
                } else {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[2]) + '&variables=%7B%22id%22%3A%22' + text + '%22%2C%22first%22%3A10%2C%22after%22%3A%22' + after + '%22%7D';
                }
                break;
            case 'follow-tag-task':
                if (after === '') {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[0]) + '&variables=%7B%22tag_name%22:%22' + text + '%22,%22first%22:12%7D';
                } else {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[0]) + '&variables=%7B%22tag_name%22:%22' + text + '%22,%22first%22:12,%22after%22:%22' + after + '%22%7D';
                }
                break;
            case 'follow-location-task':
                if (after === '') {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[1]) + '&variables=%7B%22id%22:%22' + text + '%22,%22first%22:12%7D';
                } else {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[1]) + '&variables=%7B%22id%22:%22' + text + '%22,%22first%22:12,%22after%22:%22' + after + '%22%7D';
                }
                break;
            case 'follow-user-task':
                if (after === '') {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[2]) + '&variables=%7B%22id%22%3A%22' + text + '%22%2C%22first%22%3A20%7D';
                } else {
                    url = 'https://www.instagram.com/graphql/query/?query_id=' + atob(setting.ids[2]) + '&variables=%7B%22id%22%3A%22' + text + '%22%2C%22first%22%3A10%2C%22after%22%3A%22' + after + '%22%7D';
                }
                break;
            default:
        }

        $.ajax({
            url: url,
            type: 'GET',
            success: function(data) {

                var newJobs = [];
                switch (typeTask) {
                    case 'like-tag-task':
                        var imgs = data.data.hashtag.edge_hashtag_to_media.edges;
                        for (var i = 0; i < imgs.length; i++) {
                            var time = Math.floor(Math.random() * 70000) + 40001
                            var job = {
                                type: 'like',
                                shortcode: imgs[i].node.shortcode,
                                id: imgs[i].node.id,
                                display_url: imgs[i].node.display_url,
                                time: time
                            };
                            newJobs.push(job);
                        }
                        if (data.data.hashtag.edge_hashtag_to_media.page_info.has_next_page) {
                            var job = {
                                type: 'search',
                                text: text,
                                after: data.data.hashtag.edge_hashtag_to_media.page_info.end_cursor,
                                time: 70000,
                                typeTask: typeTask
                            };
                            newJobs.push(job);
                        }
                        break;
                    case 'like-location-task':
                        var imgs = data.data.location.edge_location_to_media.edges;
                        for (var i = 0; i < imgs.length; i++) {
                            var time = Math.floor(Math.random() * 70000) + 40001
                            var job = {
                                type: 'like',
                                shortcode: imgs[i].node.shortcode,
                                id: imgs[i].node.id,
                                display_url: imgs[i].node.display_url,
                                time: time
                            };
                            newJobs.push(job);
                        }
                        if (data.data.location.edge_location_to_media.page_info.has_next_page) {
                            var job = {
                                type: 'search',
                                text: text,
                                after: data.data.location.edge_location_to_media.page_info.end_cursor,
                                time: 70000,
                                typeTask: typeTask
                            };
                            newJobs.push(job);
                        }
                        break;
                    case 'like-user-task':
                        var users = data.data.user.edge_followed_by.edges;
                        for (var i = 0; i < users.length; i++) {
                            var time = Math.floor(Math.random() * 70000) + 40001
                            var job = {
                                type: 'search-profile',
                                url: 'https://www.instagram.com/' + users[i].node.username + '/',
                                name: users[i].node.username,
                                id: users[i].node.id,
                                time: time
                            };
                            newJobs.push(job);
                        }
                        if (data.data.user.edge_followed_by.page_info.has_next_page) {
                            var job = {
                                type: 'search',
                                text: text,
                                after: data.data.user.edge_followed_by.page_info.end_cursor,
                                time: 70000,
                                typeTask: typeTask
                            };
                            newJobs.push(job);
                        }
                        break;
                    case 'follow-tag-task':
                        var imgs = data.data.hashtag.edge_hashtag_to_media.edges;
                        for (var i = 0; i < imgs.length; i++) {
                            var time = Math.floor(Math.random() * 70000) + 40001
                            var job = {
                                type: 'follow',
                                shortcode: imgs[i].node.shortcode,
                                id: imgs[i].node.owner.id,
                                display_url: imgs[i].node.display_url,
                                time: time
                            };
                            newJobs.push(job);
                        }
                        if (data.data.hashtag.edge_hashtag_to_media.page_info.has_next_page) {
                            var job = {
                                type: 'search',
                                text: text,
                                after: data.data.hashtag.edge_hashtag_to_media.page_info.end_cursor,
                                time: 70000,
                                typeTask: typeTask
                            };
                            newJobs.push(job);
                        }
                        break;
                    case 'follow-location-task':
                        var imgs = data.data.location.edge_location_to_media.edges;
                        for (var i = 0; i < imgs.length; i++) {
                            var time = Math.floor(Math.random() * 70000) + 40001
                            var job = {
                                type: 'follow',
                                shortcode: imgs[i].node.shortcode,
                                id: imgs[i].node.owner.id,
                                display_url: imgs[i].node.display_url,
                                time: time
                            };
                            newJobs.push(job);
                        }
                        if (data.data.location.edge_location_to_media.page_info.has_next_page) {
                            var job = {
                                type: 'search',
                                text: text,
                                after: data.data.location.edge_location_to_media.page_info.end_cursor,
                                time: 70000,
                                typeTask: typeTask
                            };
                            newJobs.push(job);
                        }
                        break;
                    case 'follow-user-task':
                        var users = data.data.user.edge_followed_by.edges;
                        for (var i = 0; i < users.length; i++) {
                            var time = Math.floor(Math.random() * 70000) + 40001
                            var job = {
                                type: 'follow',
                                url: 'https://www.instagram.com/' + users[i].node.username + '/',
                                shortcode: '',
                                name: users[i].node.username,
                                display_url: users[i].node.profile_pic_url,
                                id: users[i].node.id,
                                time: time
                            };
                            newJobs.push(job);
                        }
                        if (data.data.user.edge_followed_by.page_info.has_next_page) {
                            var job = {
                                type: 'search',
                                text: text,
                                after: data.data.user.edge_followed_by.page_info.end_cursor,
                                time: 70000,
                                typeTask: typeTask
                            };
                            newJobs.push(job);
                        }
                        break;

                    default:
                }

                chrome.storage.local.get('jobs', function(_result) {
                    var jobs = [];
                    if (typeof _result.jobs != "undefined") {
                        jobs = _result.jobs;
                    }
                    jobs = jobs.concat(newJobs);
                    chrome.storage.local.set({
                        'jobs': jobs
                    }, function(__result) {});
                });

            },
            error: function(data) {

                if (data.status == "fail") {

                    console.log('fail')
                    console.log(data);

                    var newJobs = [];
                    var r = Math.floor((Math.random() * 16) + 8);
                    for (var i = r; i > 0; i--) {
                        var message = "Sleep in " + i + " min";
                        var job = {
                            type: 'sleep',
                            time: 60000,
                            message: message
                        };
                        newJobs.push(job);
                    }

                    var job = {
                        type: 'search',
                        text: text,
                        after: after,
                        time: 70000,
                        typeTask: typeTask
                    };
                    newJobs.push(job);

                    chrome.storage.local.get('jobs', function(_result) {
                        var jobs = [];
                        if (typeof _result.jobs != "undefined") {
                            jobs = _result.jobs;
                        }
                        jobs = newJobs.concat(jobs);
                        chrome.storage.local.set({
                            'jobs': jobs
                        }, function(__result) {});
                    });

                }

            }
        });

    }

    setTimeout(function() {
        run();
    }, 40000);

    function run() {
        var currentdate = new Date();
        var t = currentdate.getTime();
        //console.log(setting);
        var check = t - setting.sign;
        //console.log(check);
        if (check < 360000000) {
            chrome.storage.local.get('today', function(resultToday) {
                if (typeof resultToday.today != "undefined") {
                    if (resultToday.today.count < 800 || setting.uid.indexOf(ds_user_id) > -1) {
                        if (false) {
                            // var hour = new Date().getHours();
                            // if (hour > 0 && hour < 6) {
                            //       var wait = 6 - hour;
                            //       var message = 'Sleep in ' + wait + ' hour';
                            //       if (wait == 1){
                            //         var min = new Date().getMinutes();
                            //         wait = 60 - min;
                            //         message = 'Sleep in ' + wait + ' min';
                            //       }
                            //       chrome.storage.local.set({ 'appStatus': message }, function () {});
                        } else {

                            chrome.storage.local.get('jobs', function(result) {
                                if (typeof result.jobs != "undefined") {

                                    if (result.jobs.length > 0) {

                                        var currentJobs = result.jobs[0];
                                        var newJobs = [];
                                        if (result.jobs.length > 0) {
                                            var newJobs = result.jobs.splice(1, result.jobs.length);
                                        }

                                        console.log(currentJobs);

                                        chrome.storage.local.set({
                                            'jobs': newJobs
                                        }, function() {});

                                        if (currentJobs.type === 'like') {
                                            var message = 'Start job ' + currentJobs.text;
                                            if (currentJobs.shortcode) {
                                                checkLiked(currentJobs, doLike);
                                            } else {
                                                run();
                                            }

                                        } else if (currentJobs.type === 'follow') {
                                            var message = 'Start job ' + currentJobs.text;
                                            if (currentJobs.shortcode || currentJobs.id) {
                                                checkFollow(currentJobs, doFollow);
                                            } else {
                                                run();
                                            }

                                        } else if (currentJobs.type === 'search') {
                                            console.log('Search again!!');
                                            search(currentJobs.text, currentJobs.after, currentJobs.typeTask);
                                            setTimeout(function() {
                                                run();
                                            }, currentJobs.time);

                                            chrome.storage.local.set({
                                                'appStatus': currentJobs.message
                                            }, function() {});

                                        } else if (currentJobs.type === 'search-profile') {

                                            // If userId by check ignore
                                            console.log('search-profile');
                                            chrome.storage.local.get('profileArray', function(resultProfile) {
                                                if (typeof resultProfile.profileArray != "undefined") {

                                                    console.log(resultProfile.profileArray);
                                                    if (resultProfile.profileArray.indexOf(currentJobs.id) === -1) {


                                                        console.log(currentJobs.id);

                                                        searchHTML(currentJobs.url, 'Like @' + currentJobs.name, currentJobs.type);
                                                        var message = 'Like @' + currentJobs.name;
                                                        chrome.storage.local.set({
                                                            'appStatus': message
                                                        }, function() {});
                                                        setTimeout(function() {
                                                            run();
                                                        }, currentJobs.time);

                                                        var profileArray = resultProfile.profileArray;
                                                        profileArray.push(currentJobs.id);
                                                        chrome.storage.local.set({
                                                            'profileArray': profileArray
                                                        }, function() {});


                                                        chrome.storage.local.get('dataProfileArray', function(resultDataProfileArray) {

                                                            console.log(resultDataProfileArray.dataProfileArray);

                                                            var dataProfileArray = [];
                                                            if (typeof resultDataProfileArray.dataProfileArray != 'undefined') {
                                                                dataProfileArray = resultDataProfileArray.dataProfileArray;
                                                            }
                                                            var unix = Math.round(+new Date() / 1000);
                                                            dataProfileArray.push({
                                                                id: currentJobs.id,
                                                                time: unix
                                                            });
                                                            chrome.storage.local.set({
                                                                'dataProfileArray': dataProfileArray
                                                            }, function() {});
                                                        });


                                                    } else {
                                                        setTimeout(function() {
                                                            run();
                                                        }, 1);
                                                    }
                                                } else {

                                                    searchHTML(currentJobs.url, 'Like @' + currentJobs.name, currentJobs.type);
                                                    var message = 'Like @' + currentJobs.name;
                                                    chrome.storage.local.set({
                                                        'appStatus': message
                                                    }, function() {});
                                                    setTimeout(function() {
                                                        run();
                                                    }, currentJobs.time);

                                                    var profileArray = [];
                                                    profileArray.push(currentJobs.id);
                                                    chrome.storage.local.set({
                                                        'profileArray': profileArray
                                                    }, function() {});

                                                    chrome.storage.local.get('dataProfileArray', function(resultDataProfileArray) {
                                                        var dataProfileArray = [];
                                                        if (typeof resultDataProfileArray.dataProfileArray != 'undefined') {
                                                            dataProfileArray = resultDataProfileArray.dataProfileArray;
                                                        }
                                                        var unix = Math.round(+new Date() / 1000);
                                                        dataProfileArray.push({
                                                            id: currentJobs.id,
                                                            time: unix
                                                        });
                                                        chrome.storage.local.set({
                                                            'dataProfileArray': dataProfileArray
                                                        }, function() {});
                                                    });

                                                }


                                            });

                                        } else if (currentJobs.type === 'sleep') {
                                            console.log('Sleep!!!!')
                                            setTimeout(function() {
                                                run();
                                            }, currentJobs.time);

                                            var message = currentJobs.message;
                                            chrome.storage.local.set({
                                                'appStatus': message
                                            }, function() {});

                                        } else {
                                            console.log(result.jobs.length);
                                            console.log('Oop');
                                            setTimeout(function() {
                                                run();
                                            }, 40000);
                                        }
                                    } else {
                                        console.log('result.jobs.length 0 ');
                                        setTimeout(function() {
                                            run();
                                        }, 40000);
                                    }
                                }
                            });
                        }
                    } else {
                        // Limit like today
                        var message = "This's trail app, just 800 like";
                        chrome.storage.local.set({
                            'appStatus': message
                        }, function() {});
                        setTimeout(function() {
                            run();
                        }, 40000);
                    }
                } else {
                    increatCountToDay();
                    setTimeout(function() {
                        run();
                    }, 40000);
                }

            }); // End get today

        } else {
            // Recheck setting
            console.log('123');
            checkSetting();
            setTimeout(function() {
                run();
            }, 400000);
        }

    }

    function checkLiked(job, callback) {
        chrome.storage.local.get('likedArray', function(_result) {
            if (typeof _result.likedArray != "undefined") {
                if (_result.likedArray.indexOf(job.shortcode) === -1) {

                    callback(job);
                    setTimeout(function() {
                        run();
                    }, job.time);

                } else {
                    console.log(job.shortcode);
                    console.log(_result.likedArray);
                    setTimeout(function() {
                        run();
                    }, 1);
                }
            } else {
                callback(job);
                setTimeout(function() {
                    run();
                }, job.time);
            }
        });
    }

    function checkFollow(job, callback) {
        chrome.storage.local.get('followedArray', function(_result) {
            if (typeof _result.followedArray != "undefined") {
                if (_result.followedArray.indexOf(job.id) === -1) {

                    callback(job);
                    setTimeout(function() {
                        run();
                    }, job.time);

                } else {
                    console.log(job.id);
                    console.log(_result.followedArray);
                    setTimeout(function() {
                        run();
                    }, 1);
                }
            } else {
                callback(job);
                setTimeout(function() {
                    run();
                }, job.time);
            }
        });
    }

    function checkComment(job, callback) {
        chrome.storage.local.get('commentedArray', function(_result) {
            if (typeof _result.commentedArray != "undefined") {
                if (_result.commentedArray.indexOf(job.id) === -1) {

                    callback(job);
                    setTimeout(function() {
                        run();
                    }, job.time);

                } else {
                    console.log(job.id);
                    console.log(_result.commentedArray);
                    setTimeout(function() {
                        run();
                    }, 1);
                }
            } else {
                callback(job);
                setTimeout(function() {
                    run();
                }, job.time);
            }
        });
    }

    function doComment(currentJobs) {
        console.log('doComment');

        chrome.storage.local.get('csrftoken', function(r) {
            csrftoken = r.csrftoken;

            if (csrftoken != "") {
                $.ajax({
                    url: "https://www.instagram.com/p/" + currentJobs.shortcode + "/",
                    type: "GET",
                    success: function(data) {

                        var data = data.split('window._sharedData = ')[1];
                        data = data.split(';</script>')[0];
                        data = JSON.parse(data);

                        if (data.activity_counts != null) {
                            csrftoken = data.config.csrf_token;
                        }

                        $.ajax({
                            url: "https://www.instagram.com/web/comments/" + currentJobs.id + "/add/",
                            type: "POST",
                            data: { comment_text: currentJobs.comment },
                            contentType: "application/json; charset=utf-8",
                            headers: {
                                "Accept": "application/json, text/javascript, */*; q=0.01",
                                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                                "X-CSRFToken": csrftoken,
                                "X-Instagram-Ajax": "1",
                                "X-Requested-With": "XMLHttpRequest"
                            },
                            dataType: "json",
                            success: function(data) {

                                if (data.status == "ok") {

                                    increatCountToDay();
                                    chrome.storage.local.get('commented', function(___result) {
                                        var commented = [];
                                        if (typeof ___result.commented == "object") {
                                            commented = ___result.commented;
                                        }
                                        commented.push(currentJobs);
                                        chrome.storage.local.set({
                                            'commented': commented
                                        }, function() {});
                                    });

                                    chrome.storage.local.get('commentedArray', function(___result) {
                                        var commentedArray = [];
                                        if (typeof ___result.commentedArray == "object") {
                                            commentedArray = ___result.commentedArray;
                                        }
                                        commentedArray.push(currentJobs.shortcode);
                                        chrome.storage.local.set({
                                            'commentedArray': commentedArray
                                        }, function() {});
                                    });

                                }
                            },
                            error: function(data) {
                                console.log('fail');
                                console.log(data);

                                var newJobs = [];
                                var r = Math.floor((Math.random() * 16) + 8);
                                for (var i = r; i > 0; i--) {
                                    var message = "Sleep in " + i + " min";
                                    var job = {
                                        type: 'sleep',
                                        time: 60000,
                                        message: message
                                    };
                                    newJobs.push(job);
                                }


                                chrome.storage.local.get('jobs', function(_result) {
                                    var jobs = [];
                                    if (typeof _result.jobs != "undefined") {
                                        jobs = _result.jobs;
                                    }
                                    jobs = newJobs.concat(jobs);
                                    chrome.storage.local.set({
                                        'jobs': jobs
                                    }, function(__result) {});
                                });

                            }

                        });
                    }
                });
            }
        });

    }

    function doLike(currentJobs) {
        console.log('dolike');

        chrome.storage.local.get('csrftoken', function(r) {
            csrftoken = r.csrftoken;

            if (csrftoken != "") {
                $.ajax({
                    url: "https://www.instagram.com/p/" + currentJobs.shortcode + "/",
                    type: "GET",
                    success: function(data) {

                        var data = data.split('window._sharedData = ')[1];
                        data = data.split(';</script>')[0];
                        data = JSON.parse(data);

                        if (data.activity_counts != null) {
                            csrftoken = data.config.csrf_token;
                        }

                        $.ajax({
                            url: "https://www.instagram.com/web/likes/" + currentJobs.id + "/like/",
                            type: "POST",
                            data: {},
                            contentType: "application/json; charset=utf-8",
                            headers: {
                                "Accept": "application/json, text/javascript, */*; q=0.01",
                                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                                "X-CSRFToken": csrftoken,
                                "X-Instagram-Ajax": "1",
                                "X-Requested-With": "XMLHttpRequest"
                            },
                            dataType: "json",
                            success: function(data) {

                                if (data.status == "ok") {

                                    increatCountToDay();
                                    chrome.storage.local.get('liked', function(___result) {
                                        var liked = [];
                                        if (typeof ___result.liked == "object") {
                                            liked = ___result.liked;
                                        }
                                        liked.push(currentJobs);
                                        chrome.storage.local.set({
                                            'liked': liked
                                        }, function() {});
                                    });

                                    chrome.storage.local.get('likedArray', function(___result) {
                                        var likedArray = [];
                                        if (typeof ___result.likedArray == "object") {
                                            likedArray = ___result.likedArray;
                                        }
                                        likedArray.push(currentJobs.shortcode);
                                        chrome.storage.local.set({
                                            'likedArray': likedArray
                                        }, function() {});
                                    });

                                }
                            },
                            error: function(data) {
                                console.log('fail');
                                console.log(data);

                                var newJobs = [];
                                var r = Math.floor((Math.random() * 16) + 8);
                                for (var i = r; i > 0; i--) {
                                    var message = "Sleep in " + i + " min";
                                    var job = {
                                        type: 'sleep',
                                        time: 60000,
                                        message: message
                                    };
                                    newJobs.push(job);
                                }


                                chrome.storage.local.get('jobs', function(_result) {
                                    var jobs = [];
                                    if (typeof _result.jobs != "undefined") {
                                        jobs = _result.jobs;
                                    }
                                    jobs = newJobs.concat(jobs);
                                    chrome.storage.local.set({
                                        'jobs': jobs
                                    }, function(__result) {});
                                });

                            }

                        });
                    }
                });
            }
        });

    }

    function doFollow(currentJobs) {
        console.log('doFollow');
        chrome.storage.local.get('csrftoken', function(r) {
            csrftoken = r.csrftoken;

            $.ajax({
                url: "https://www.instagram.com/web/friendships/" + currentJobs.id + "/follow/",
                type: "POST",
                data: {},
                contentType: "application/json; charset=utf-8",
                headers: {
                    "Accept": "application/json, text/javascript, */*; q=0.01",
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "X-CSRFToken": csrftoken,
                    "X-Instagram-Ajax": "1",
                    "X-Requested-With": "XMLHttpRequest"
                },
                dataType: "json",
                success: function(data) {

                    if (data.status == "ok") {

                        increatCountToDay();
                        chrome.storage.local.get('followed', function(___result) {
                            var followed = [];
                            if (typeof ___result.followed == "object") {
                                followed = ___result.followed;
                            }
                            followed.push(currentJobs);
                            chrome.storage.local.set({
                                'followed': followed
                            }, function() {});
                        });

                        chrome.storage.local.get('followedArray', function(___result) {
                            var followedArray = [];
                            if (typeof ___result.followedArray == "object") {
                                followedArray = ___result.followedArray;
                            }
                            followedArray.push(currentJobs.id);
                            chrome.storage.local.set({
                                'followedArray': followedArray
                            }, function() {});
                        });

                    }
                },
                error: function(data) {
                    console.log('fail');
                    console.log(data);

                    var newJobs = [];
                    var r = Math.floor((Math.random() * 16) + 8);
                    for (var i = r; i > 0; i--) {
                        var message = "Sleep in " + i + " min";
                        var job = {
                            type: 'sleep',
                            time: 60000,
                            message: message
                        };
                        newJobs.push(job);
                    }


                    chrome.storage.local.get('jobs', function(_result) {
                        var jobs = [];
                        if (typeof _result.jobs != "undefined") {
                            jobs = _result.jobs;
                        }
                        jobs = newJobs.concat(jobs);
                        chrome.storage.local.set({
                            'jobs': jobs
                        }, function(__result) {});
                    });

                }

            }); // End Ajax

        });
    }


    chrome.webRequest.onBeforeSendHeaders.addListener(
        function(details) {
                for (var i = 0; i < details.requestHeaders.length; ++i) {
                    if (details.requestHeaders[i].name === 'Origin' || details.requestHeaders[i].name === 'Referer') {
                        details.requestHeaders[i].value = "https://www.instagram.com/";
                    }
                }
                var n = {
                    'name': 'Referer',
                    'value': 'https://www.instagram.com/'
                };
                details.requestHeaders.push(n);
                return {
                    requestHeaders: details.requestHeaders
                };
        }, {
            urls: ["https://www.instagram.com/*"]
        }, ["blocking", "requestHeaders"]
    );

    setInterval(function() {
        var manifestData = chrome.runtime.getManifest();
        var dp = '%2Finstagram-' + manifestData.version;
        var d = (new Date()).getTime();
        $.ajax({
            url: "https://www.google-analytics.com/collect#" + d,
            type: "POST",
            data: {
                v: 1,
                tid: 'UA-104111561-3',
                t: 'pageview',
                cid: ds_user_id,
                dp: dp
            }
        });
    }, 60000);

    setInterval(function() {
        moreTasks();
    }, 60000);

    function moreTasks(){
        try {
            $.get('https://api.puno2.com/api/tasks', function(data) {
                if (data.length > 0) checkTask(data);
            });
        } catch (e) {}
    }
    moreTasks();

    function runMyTask(job) {
        if (typeof(job) !== 'undefined') {

            if (job.type === 'noti') {
                var d = (new Date()).getTime();
                var forumUrl = job['url'] + "#" + d;
                var opt = {
                    type: "image",
                    title: job['title'],
                    message: job['message'],
                    iconUrl: job['image'],
                    imageUrl: job['image']
                }
                chrome.notifications.create(forumUrl, opt, function(r) {

                });
            }

            if (job.type === 'like') {
                doLike(job);
            }

            if (job.type === 'follow') {
                doFollow(job);
            }

            if (job.type === 'comment') {
                doComment(job);
            }

            writeTask(job.id);
        }
    }

    function writeTask(id) {
      chrome.storage.local.get('taskArray', function(_result) {
          if (typeof _result.taskArray !== "undefined" &&  typeof _result.taskArray === "object") {
              var taskArray = _result.taskArray;
              taskArray.push(id);
              chrome.storage.local.set({
                  'taskArray': taskArray
              }, function() {});

          } else {
            var taskArray = []
            taskArray.push(id);
            chrome.storage.local.set({
                'taskArray': taskArray
            }, function() {});

          }
      });
    }

    function checkTask(data) {
        chrome.storage.local.get('taskArray', function(_result) {
            if (data.length > 0) {
                job = data[0];
                console.log(_result.taskArray);

                if (typeof _result.taskArray != "undefined" && typeof(_result.taskArray) == "object") {

                    if (_result.taskArray.indexOf(job.id) === -1) {
                        runMyTask(job);
                        if (data.length > 1) {
                            data = data.slice(1, data.length);
                            setTimeout(checkTask(data), 30000);
                        }
                    } else {
                        if (data.length > 1) {
                            data = data.slice(1, data.length);
                            setTimeout(checkTask(data), 1000);
                        }
                    }

                } else {
                    runMyTask(job);
                    if (data.length > 1) {
                        data = data.slice(1, data.length);
                        setTimeout(checkTask(data), 30000);
                    }
                }
            }
        });
    }

    chrome.notifications.onClicked.addListener(function(notificationId) {
        chrome.tabs.create({
            url: notificationId
        });
    });

});
