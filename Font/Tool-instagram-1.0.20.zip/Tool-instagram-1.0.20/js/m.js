$(document).ready(function() {

    var api = "https://i.instagram.com/api/v1/";
    
    $.ajax({
        url: 'https://www.instagram.com',
        type: 'GET',
        success: function(data) {
            var data = data.split('window._sharedData = ')[1];
            data = data.split(';</script>')[0];
            data = JSON.parse(data);


            var csrftoken = '';
            var ds_user_id = '';


            if (data.config != null) {
                csrftoken = data.config.csrf_token;
                console.log(data.config);
                ds_user_id = data.config.viewer.id;

            }


            if (csrftoken == "") {

                chrome.storage.local.set({
                    'state': 'login'
                }, function(__result) {});
                chrome.tabs.create({
                    url: "https://www.instagram.com/"
                });
                

            } else {

                chrome.storage.local.set({
                    'csrftoken': csrftoken
                }, function(result) {})


                $.get(api + "users/" + ds_user_id + "/info/")
                    .done(function(response) {
                        if (typeof response == 'object') {

                            var html = '<div class="myRow" style="width: 100%;background-color: rgb(250, 250, 250);padding: 8px 5px 8px 0px;flex: 0 0 auto;" >' +
                                '<div class="myRow" style="border-radius: 6px;padding-right: 10px;" >' +
                                '<img src="/images/account-at.svg" width="15" height="15">' +
                                '<div style="width: 6px;height: 0px;visibility: hidden;flex: 0 0 auto;transition: all 300ms cubic-bezier(0.23, 1, 0.32, 1) 0ms;"></div>' +
                                '<span style="font-weight: 500; margin-bottom: 1px; text-overflow: ellipsis; white-space: nowrap; font-size: 11px; opacity: 0.64; letter-spacing: 0em; line-height: 1.333; color: rgb(0, 0, 0); max-width: 230px; overflow: hidden;">' +
                                response.user.username +
                                '</span></div>' +
                                '<div style="flex: 1 0 auto;" ></div>' +
                                '<div class="myRow">' +
                                '<div style="cursor: pointer;pointer-events: all;">' +
                                '<img src="/images/edit.png" width="15" height="15"><a name="updateAccount" id="updateAccount">Update</a>' +
                                '</div>' +
                                '</div>' +
                                '</div>' +
                                '</div>' +
                                '</div>';

                            $('#account').append(html);
                            chrome.storage.local.set({
                                'user': data
                            }, function(result) {});
                        }
                    });

                chrome.storage.local.get('tasks', function(result) {
                    if (typeof result.tasks == "undefined") {
                        chrome.storage.local.set({
                            'state': 'task'
                        }, function(__result) {});
                    } else {
                        // chrome.storage.local.set({ 'state': 'home' }, function (__result) {});
                    }
                });

            }
        }
    });




    chrome.storage.local.get('state', function(result) {
        var _main = document.getElementsByClassName('main');
        for (var i = 0; i < _main.length; i++) {
            _main[i].setAttribute('style', 'display: none;');
        }
        console.log(result.state);

        switch (result.state) {
            case "login":
                document.getElementById('login').setAttribute('style', 'display: block;');
                break;
            case "home":
                document.getElementById('home').setAttribute('style', 'display: block;');
                break;
            case "task":
                updateTask();
                document.getElementById('task').setAttribute('style', 'display: block;');
                break;
            case "addTask":
                document.getElementById('addTask').setAttribute('style', 'display: block;');
                break;
            default:
                document.getElementById('home').setAttribute('style', 'display: block;');
                break;
        }
    });

    function updateTask() {
        chrome.storage.local.get('tasks', function(_result) {
            if (typeof _result.tasks != "undefined") {

                document.getElementById('tasks').innerHTML = '';

                for (var i = 0; i < _result.tasks.length; i++) {


                    var icon = '';
                    var text = '';
                    if (_result.tasks[i].type == 'like-location-task' || _result.tasks[i].type == 'follow-location-task') {
                        icon = '/images/task-by-location@2x.png';
                        text = _result.tasks[i].dataTask.split('/')[6];
                    }

                    if (_result.tasks[i].type == 'like-tag-task' || _result.tasks[i].type == 'follow-tag-task') {
                        icon = '/images/task-by-tag@2x.png';
                        text = _result.tasks[i].dataTask;
                    }

                    if (_result.tasks[i].type == 'like-user-task' || _result.tasks[i].type == 'follow-user-task') {
                        icon = '/images/task-by-username@2x.png';
                        text = _result.tasks[i].dataTask
                    }

                    var html = '<div style=" width: 100%; margin-bottom: 16px; box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 6px 0px; z-index: 1; border-width: initial; border-style: none; border-color: initial; border-image: initial; border-radius: 4px; -webkit-box-orient: horizontal; -webkit-box-direction: normal; display: flex; flex-direction: row; ">' +
                        '<div style=" position: relative; z-index: 1; cursor: pointer; background-color: rgb(248, 248, 248); padding: 10px; transition: all 300ms cubic-bezier(0.23, 1, 0.32, 1) 0ms; border-right: 1px solid rgb(240, 240, 240); border-radius: 4px 0px 0px 4px; -webkit-box-orient: vertical; -webkit-box-direction: normal; -webkit-box-align: center; display: flex; flex-direction: column; align-items: center;">' +
                        '<img src="' + icon + '" width="43" height="39">' +
                        '<div data-css-s35e7l="" data-css-w7fjnz=""></div>' +
                        '<div style="cursor: pointer; position: relative; overflow: visible; display: table; height: auto; width: 100%; margin-right: 5px;">' +
                        '</div>' +
                        '</div>' +
                        '<div style=" cursor: pointer; z-index: 0; background-color: rgb(252, 252, 252); position: relative; flex: 1 0 0%; border-radius: 0px 4px 4px 0px; padding: 8px 12px; transition: all 300ms cubic-bezier(0.23, 1, 0.32, 1) 0ms;">' +
                        '<div style="font-weight: 400;margin-bottom: 8px;text-overflow: ellipsis;white-space: nowrap;font-size: 14px;opacity: 0.87;letter-spacing: 0em;line-height: 1.333;color: rgb(0, 0, 0);width: 190px;overflow: hidden;">' + text + '</div>' +
                        '<div style="margin-bottom: 4px;font-size: 9px;font-weight: 400;opacity: 0.5;letter-spacing: 0em;line-height: 1.333;color: rgb(0, 0, 0);">' +
                        '<span data-css-41sc57=""></span>' +
                        '<span data-css-41sc57=""></span>' +
                        '</div>' +
                        '<div style="margin-top: 8px; font-size: 9px; font-weight: 400; opacity: 1; letter-spacing: 0em; line-height: 1.333; color: rgb(21, 232, 0); -webkit-box-orient: horizontal; -webkit-box-direction: normal; -webkit-box-align: center; display: flex; flex-direction: row; align-items: center;">' +
                        '<img src="/images/running.svg" width="10" height="10">' +
                        '<div data-css-s35e7l="" data-css-994nvj=""></div>' +
                        '<div><span data-css-41sc57="">&nbsp;running:&nbsp;</span>' +
                        '<span style="color: rgb(0, 0, 0);opacity: 0.5;"></span></div>' +
                        '</div>' +

                        '<div style="position: absolute;top: 8px;right: 8px;z-index: 0;"><img src="/images/delete.png" style="height: 24px;cursor: pointer;" class="btnDeleteTask" data-id="' + _result.tasks[i].id + '"/></div>' +

                        '</div>' +
                        '</div>';

                    $('#tasks').append(html);

                }

                var btnDeleteTasks = document.getElementsByClassName("btnDeleteTask");
                for (var i = 0; i < btnDeleteTasks.length; i++) {
                    document.getElementsByClassName("btnDeleteTask")[i].addEventListener("click", deleteTask.bind(this));

                    function deleteTask(e) {
                        var id = e.srcElement.attributes[3].value;


                        chrome.storage.local.get('tasks', function(_result) {
                            if (typeof _result.tasks != "undefined") {
                                for (var i = 0; i < _result.tasks.length; i++) {
                                    if (_result.tasks[i].id == id) {
                                        _result.tasks.splice(i, 1);
                                        break;
                                    }
                                }
                                chrome.storage.local.set({
                                    'tasks': _result.tasks
                                }, function() {});
                                updateTask();
                            }
                        });


                    }
                }

            }
        });
    }

    chrome.storage.onChanged.addListener(function(changes, namespace) {
        for (key in changes) {
            var storageChange = changes[key];

            if (key == 'state' && namespace == 'local') {
                var _main = document.getElementsByClassName('main');
                for (var i = 0; i < _main.length; i++) {
                    _main[i].setAttribute('style', 'display: none;');
                }

                console.log(storageChange.newValue);

                switch (storageChange.newValue) {
                    case "login":
                        document.getElementById('login').setAttribute('style', 'display: block;');
                        break;
                    case "home":
                        document.getElementById('home').setAttribute('style', 'display: block;');
                        break;
                    case "task":
                        updateTask();
                        document.getElementById('task').setAttribute('style', 'display: block;');
                        break;
                    case "addTask":
                        document.getElementById('addTask').setAttribute('style', 'display: block;');
                        break;
                    default:
                        document.getElementById('login').setAttribute('style', 'display: block;');
                        break;
                }
            }
        }
    });

    document.getElementById("btnAddTask").addEventListener("click", addTask);

    function addTask() {
        document.getElementById('dataTask').value = '';
        chrome.storage.local.set({
            'state': 'addTask'
        }, function(result) {});
    }

    document.getElementById("btnSaveTask").addEventListener("click", saveTask);

    function saveTask() {

        var id = Math.round(+new Date() / 1000);
        var type = $('#typeTask').val();
        var dataTask = $('#dataTask').val();

        if (dataTask != '') {
            var task = {
                id: id,
                type: type,
                dataTask: dataTask
            };

            chrome.storage.local.get('tasks', function(result) {

                var tasks = [];
                if (typeof result.tasks != "undefined") {
                    tasks = result.tasks;
                }

                tasks.push(task);
                chrome.storage.local.set({
                    'tasks': tasks
                }, function(_result) {});

                chrome.storage.local.set({
                    'state': 'task'
                }, function(_result) {});
            });
        }

    }

    document.getElementById("btnTask").addEventListener("click", editTask);

    function editTask() {
        chrome.storage.local.set({
            'state': 'task'
        }, function(result) {});
    }

    document.getElementById("btnBackToTask").addEventListener("click", editTask);

    function backToTask() {
        chrome.storage.local.set({
            'state': 'task'
        }, function(result) {});
    }

    document.getElementById("btnTaskBack").addEventListener("click", taskBack);

    function taskBack() {
        chrome.storage.local.set({
            'state': 'home'
        }, function(result) {});
    }
    document.getElementById("btnUpgradePro").addEventListener("click", upgradePro);
    function upgradePro() {
      var newURL = "https://atpsoft.vn/simple-instagram.html";
      chrome.tabs.create({ url: newURL });
    }

    document.getElementById("typeTask").addEventListener("change", selectTypeTask);

    function selectTypeTask() {
        switch ($('#typeTask').val()) {
            case "like-tag-task":
                document.getElementById('dataTask').setAttribute('placeholder', '#shop #travel ...');
                break;
            case "like-location-task":
                document.getElementById('dataTask').setAttribute('placeholder', 'https://www.instagram.com/explore/locations/108458769184495/ho-chi-minh-city-vietnam/');
                break;
            case "like-user-task":
                document.getElementById('dataTask').setAttribute('placeholder', '@userA @userB...');
                break;
            case "follow-tag-task":
                document.getElementById('dataTask').setAttribute('placeholder', '#shop #travel ...');
                break;
            case "follow-location-task":
                document.getElementById('dataTask').setAttribute('placeholder', 'https://www.instagram.com/explore/locations/108458769184495/ho-chi-minh-city-vietnam/');
                break;
            case "follow-user-task":
                document.getElementById('dataTask').setAttribute('placeholder', '@userA @userB...');
                break;
            default:
                document.getElementById('dataTask').setAttribute('placeholder', ' #shop #travel ...');
        }

    }

    function update() {
        chrome.storage.local.get('appStatus', function(___result) {
            if(typeof ___result.appStatus != "undefined") {
              document.getElementById('appStatus').innerHTML = ___result.appStatus;
            } else {
              document.getElementById('appStatus').innerHTML = "You must create new task";
            }
        });

        chrome.storage.local.get('liked', function(_result) {
            if (typeof _result.liked == "object") {
                var liked = _result.liked;
                document.getElementById('totalLike').innerHTML = liked.length;
                document.getElementById('liked').innerHTML = '';
                var _liked = liked.splice(liked.length - 24, liked.length);
                _liked.reverse();
                for (var i = 0; i < _liked.length && i < 24; i++) {
                    var html = "<img src='" + _liked[i].display_url + "' height='48px' width='48px' />";
                    $('#liked').append(html);
                }
            }
        });

        chrome.storage.local.get('today', function(result) {
            document.getElementById('todayLike').innerHTML = result.today.count;
        });
    }
    update();

    setInterval(function() {
        var unix = Math.round(+new Date() / 1000);
        console.log(unix);
        update();
    }, 5000);

});
