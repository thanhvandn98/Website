import React, { useState } from 'react'
import SingleColor from './SingleColor'

import Values from 'values.js'

function App() {
  return <h2>color generator project</h2>
}

export default App
