import React from 'react'
import { useGlobalContext } from './context'

const Buttons = () => {
  return <h2>prev and next buttons</h2>
}

export default Buttons
