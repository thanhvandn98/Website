import React, { useState } from 'react'
import ReactMarkdown from 'react-markdown'

function App() {
  return <h2>markdown preview starter</h2>
}

export default App
