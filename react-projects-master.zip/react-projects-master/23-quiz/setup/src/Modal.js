import React from 'react'
import { useGlobalContext } from './context'

const Modal = () => {
  return <h2> Modal Component</h2>
}

export default Modal
